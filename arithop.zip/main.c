/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int a,b,c,d,i;
    printf("enter two numbers:");
    scanf("%d%d",&a,&b);
    
    c=a-b;
    printf("difference is :%d\n",c);
    
   
    c=a*b;
    printf("product is :%d\n",c);
   
    
    c=a/b;
    printf("division is :%d\n",c);
   
    
    c=a%b;
    printf("modulus is :%d\n",c);
   
   
    c=a+b;
    printf("sum is :%d\n",c);
    
   
    printf("increment  is:%d\n",++a);
    printf("decrement  is:%d\n",++b);
    
    return 0;
}